export default [
  require('C:\\Users\\rexme\\OneDrive\\rexmen\\GithubBlog\\codetenshu\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Users\\rexme\\OneDrive\\rexmen\\GithubBlog\\codetenshu\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Users\\rexme\\OneDrive\\rexmen\\GithubBlog\\codetenshu\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Users\\rexme\\OneDrive\\rexmen\\GithubBlog\\codetenshu\\src\\css\\custom.css'),
];
